document.addEventListener("DOMContentLoaded", () => {
    console.log("CCSFix Frontend Loaded");
  });