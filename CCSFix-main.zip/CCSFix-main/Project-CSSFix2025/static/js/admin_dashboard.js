// Return button functionality
document.addEventListener('DOMContentLoaded', function() {
    const returnBtn = document.querySelector('.return-btn');
    if (returnBtn) {
        returnBtn.addEventListener('click', function(e) {
            e.preventDefault();
            history.back();
        });
    }
}); 