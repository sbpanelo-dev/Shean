// Handle return button click
document.querySelector('.return-btn').addEventListener('click', function(e) {
    e.preventDefault();
    history.back();
}); 