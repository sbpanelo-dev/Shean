document.querySelectorAll('.scroll-indicator').forEach(indicator => {
  indicator.addEventListener('click', () => {
    const section = indicator.closest('section');
    const nextSection = section.nextElementSibling;
    if (nextSection) {
      nextSection.scrollIntoView({ behavior: 'smooth' });
    }
  });
});

function showTab(tabName) {
  // Hide all tabs
  document.querySelectorAll('.tab-content').forEach(tab => {
    tab.classList.remove('active');
  });
  document.querySelectorAll('.tab-button').forEach(button => {
    button.classList.remove('active');
  });

  // Show selected tab
  document.getElementById(tabName + '-tab').classList.add('active');
  document.querySelector(`button[onclick="showTab('${tabName}')"]`).classList.add('active');
} 