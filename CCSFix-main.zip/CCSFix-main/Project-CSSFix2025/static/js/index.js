function validateId(input) {
  const studentPattern = /^\d{2}-\d{5}$/;
  const role = document.getElementById('role').value;
  
  if (role === 'student') {
    if (!studentPattern.test(input.value)) {
      input.setCustomValidity('Please enter a valid Student ID in format: YY-XXXXX (e.g., 24-35960)');
    } else {
      input.setCustomValidity('');
    }
  } else {
    input.setCustomValidity('');
  }
}

function updateIdValidation() {
  const idInput = document.getElementById('student_id');
  validateId(idInput);
} 