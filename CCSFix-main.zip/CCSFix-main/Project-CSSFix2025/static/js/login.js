function updateIdValidation() {
    const role = document.getElementById('role').value;
    const studentIdInput = document.getElementById('student_id');
    const studentIdLabel = document.querySelector('label[for="student_id"]');
    
    if (role === 'student') {
        studentIdInput.setAttribute('pattern', '\\d{2}-\\d{5}');
        studentIdInput.setAttribute('title', 'Please enter a valid Student ID in format: YY-XXXXX (e.g., 24-35960)');
        studentIdInput.placeholder = 'e.g., 24-35960';
        studentIdLabel.textContent = 'Student ID';
    } else {
        studentIdInput.removeAttribute('pattern');
        studentIdInput.setAttribute('title', 'Enter your admin ID');
        studentIdInput.placeholder = 'Enter admin ID';
        studentIdLabel.textContent = 'Admin ID';
    }
}

function validateId(input) {
    const studentIdPattern = /^\d{2}-\d{5}$/;
    const roleSelect = document.getElementById('role');
    const isStudent = roleSelect.value === 'student';
    
    if (isStudent) {
        if (!studentIdPattern.test(input.value)) {
            input.setCustomValidity('Please enter a valid Student ID in format: YY-XXXXX (e.g., 24-35960)');
        } else {
            input.setCustomValidity('');
        }
    } else {
        input.setCustomValidity('');
    }
}

document.addEventListener('DOMContentLoaded', function() {
    updateIdValidation();
}); 