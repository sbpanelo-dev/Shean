const actualBtn = document.getElementById('photo');
const fileChosen = document.getElementById('file-chosen');
const preview = document.getElementById('preview');

actualBtn.addEventListener('change', function(){
    fileChosen.textContent = this.files[0] ? this.files[0].name : 'No file chosen';
});

function previewImage(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
        }
        
        reader.readAsDataURL(input.files[0]);
    }
}

function openModal(imageSrc) {
    const modal = document.getElementById('imageModal');
    const modalImg = document.getElementById('modalImage');
    modal.style.display = 'flex';
    modalImg.src = imageSrc;
}

function closeModal() {
    document.getElementById('imageModal').style.display = 'none';
}

// Close modal when pressing escape key
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeModal();
    }
});

// Prevent modal from closing when clicking on the image
document.getElementById('modalImage').addEventListener('click', function(event) {
    event.stopPropagation();
}); 