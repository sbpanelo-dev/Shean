// Custom validation for student ID
document.getElementById('student_id').addEventListener('input', function(e) {
    const value = e.target.value;
    const isValid = /^\d{2}-\d{5}$/.test(value);
    
    if (!isValid && value !== '') {
        e.target.setCustomValidity('Please enter a valid student ID in format: YY-XXXXX (e.g., 24-35960)');
        e.target.classList.add('is-invalid');
    } else {
        e.target.setCustomValidity('');
        e.target.classList.remove('is-invalid');
    }
}); 